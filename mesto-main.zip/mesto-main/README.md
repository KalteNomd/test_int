# Проект: Место

## Описание
Учебный проект в Яндекс Практикуме по верстке одностраничного, адаптивного сайта с использованием js.

## Макет
https://www.figma.com/file/2cn9N9jSkmxD84oJik7xL7/JavaScript.-Sprint-4?node-id=0%3A1

## Используемые технологии
* HTML
* CSS
* Адаптивная верстка
* Применялся подход БЭМ
* JS 

## Ссылка на сайт
https://viktoriya-eismont.github.io/mesto/
